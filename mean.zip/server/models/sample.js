var mongoose = require('mongoose');
mongoose.Promise = global.Promise;
var Schema = mongoose.Schema;
var modelSchema = new mongoose.Schema ({
	name : {type: String, required: true},
	created_at: {type: Date, default: Date.now}
})
mongoose.model('Model', modelSchema);